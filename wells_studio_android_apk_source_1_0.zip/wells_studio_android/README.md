# Wells Studio Android — paquet de compilation 1.0

Ce paquet reprend Wells Studio version 1.0 dans une enveloppe Android WebView. Il conserve l’éditeur HTML/CSS/JavaScript, l’aperçu, la gestion des projets et le stockage local. Les exports HTML et JSON sont dirigés vers `Téléchargements/Wells Studio` sur Android 10 ou plus récent. Le sélecteur Android permet de choisir un fichier JSON pour importer une sauvegarde.

## Important

- Cette archive contient le projet source Android, pas un APK déjà compilé.
- La compilation debug produit un APK installable pour test. Ce n’est pas une version signée pour publication sur le Play Store.
- La compilation distante doit réussir avant que l’APK puisse être téléchargé. Le projet n’a pas été compilé sur un téléphone physique dans cet environnement.
- Avant d’y conserver des projets importants, teste la sauvegarde JSON et garde une copie externe.

## Procédure prévue pour un téléphone Android seulement

1. Télécharge cette archive et garde-la dans **Téléchargements**.
2. Dans le navigateur, ouvre GitHub et crée un dépôt vide (bouton **New**). Un compte GitHub est nécessaire.
3. Dans ce dépôt, utilise **Add file → Upload files** et téléverse uniquement `wells_studio_android_apk_source_1_0.zip`.
4. Crée ensuite le fichier `.github/workflows/build-apk.yml` dans GitHub (**Add file → Create new file**). Le contenu à coller est fourni dans le fichier séparé `wells_studio_build_apk.yml` livré avec le paquet de travail.
5. Ouvre **Actions**, sélectionne **Construire APK Wells Studio**, puis **Run workflow**.
6. Lorsque le travail est terminé en vert, ouvre son exécution, descends à **Artifacts**, télécharge `Wells-Studio-APK-debug.zip`, puis extrais `app-debug.apk`.
7. Ouvre l’APK sur ton téléphone et autorise l’installation depuis cette source si Android le demande.

Le workflow distant décompresse cette archive et compile le projet avec Java, Gradle et le SDK Android. Si GitHub te demande d’autoriser les actions, active-les dans l’onglet **Actions**.

## Identifiants Android

- Nom affiché : Wells Studio
- Application ID : `com.wellsstudio.app`
- Version : 1.0 (versionCode 1)
- SDK minimum : Android 6.0 (API 23)
- SDK cible : Android 15 (API 35)
